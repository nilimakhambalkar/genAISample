import React from 'react';
import { Box } from '@mui/material';
import AppHeader from './components/AppHeader';
import DocSearchForm from './components/DocSearchForm';

function App() {
  return (
    <Box>
      <AppHeader />
      <Box sx={{ p: 3, mt: 8 }}>
        <DocSearchForm />
      </Box>
    </Box>
  );
}

export default App;
