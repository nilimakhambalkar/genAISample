
import { AgGridReact } from 'ag-grid-react'; // React Data Grid Component


function DocResultsGrid({ rowData }) {

   
    // ...

  const columnDefs = [
    { field: 'name', headerName: 'Document Name', flex: 2 },
    {
      field: 'status',
      headerName: 'Status',
      flex: 1,
      cellStyle: (params) => ({
        color: params.value === 'found' ? 'green' : 'red',
        fontWeight: 'bold'
      })
    },
    {
      headerName: 'Download',
      field: 'url',
      flex: 1,
      cellRenderer: (params) => (
        <a href={params.value} download target="_blank" rel="noopener noreferrer">
          🔽 Download
        </a>
      )
    },
    {
      headerName: 'View Source',
      field: 'url',
      flex: 1,
      cellRenderer: (params) => (
        <a href={params.value} target="_blank" rel="noopener noreferrer">
          🌐 View
        </a>
      )
    }
  ];

  return (
    <div className="ag-theme-alpine" style={{ height: 600, width: '100%' }}>
        <div style={{ height: 500 }}>
        <AgGridReact
            rowData={[
                { make: "Tesla", model: "Model Y", price: 64950, electric: true },
                { make: "Ford", model: "F-Series", price: 33850, electric: false },
                { make: "Toyota", model: "Corolla", price: 29600, electric: false },
            ]}
            columnDefs={[
                { field: "make" },
                { field: "model" },
                { field: "price" },
                { field: "electric" }
            ]}
        />
    </div>
      <AgGridReact
        rowData={rowData}
        columnDefs={columnDefs}
        defaultColDef={{
          sortable: true,
          filter: true,
          resizable: true
        }}
      />
    </div>
  );
}

export default DocResultsGrid;
