import {
    Container,
    Grid,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Checkbox,
    ListItemText,
    Button,
    CircularProgress,
    Typography,
    Box,
    FormLabel
} from '@mui/material';
import React, { useState } from 'react';
import axios from 'axios';
import DocResultsGrid from './DocResultsGrid';
import DocResultsTable from './DocResultsTable';

const banks = [
    { name: 'JPMorgan Chase', id: 'jpm',  irUrl: 'https://www.jpmorganchase.com', },
    { name: 'Bank of America', id: 'bofa' ,  irUrl: 'https://investor.bankofamerica.com/quarterly-earnings',},
    { name: 'Citibank', id: 'citi', irUrl: 'https://www.citigroup.com/global/investors/quarterly-earnings', },
    { name: 'Wells Fargo', id: 'wells',  irUrl: 'https://www.wellsfargo.com/about/investor-relations/earnings/' },
    { name: 'Capital One', id: 'capone',irUrl: 'https://www.capitalone.com/about/investors/events-and-presentations/' },
    { name: 'Synchrony', id: 'sync',irUrl: 'https://investors.synchrony.com/financials/quarterly-results/default.aspx' },
    { name: 'American Express', id: 'amex',irUrl: 'https://ir.americanexpress.com/quarterly-earnings/default.aspx'}
];


const docTypes = ['Press Release', 'Presentation', 'Supplement', 'Transcript'];

const quarters = ['Q1 2025', 'Q1 2024', 'Q2 2024', 'Q3 2024','Q4 2024', 'Q1 2023', 'Q2 2023', 'Q3 2023', 'Q4 2023'];


function DocSearchForm() {
    const [selectedBanks, setSelectedBanks] = useState([]);
    const [selectedDocs, setSelectedDocs] = useState([]);
    const [selectedQuarters, setSelectedQuarters] = useState([]);
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleSearch = async () => {
        setLoading(true);
        try {
          const res = await axios.post('http://localhost:5000/search-doc', {
            banks: selectedBanks,
            docTypes: selectedDocs,
            quarters: selectedQuarters,
          });
          setResult(res.data);
        } catch (err) {
          console.error('Fetch failed:', err);
          let rowdata = [
            {
              "id": "jpm-press-2024Q1",
              "bankId": "jpm",
              "docType": "press",
              "name": "JPMorgan Chase",
              "period":"2025Q1",
              "url": "https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2025/1st-quarter/d88c408a-bbc9-4b06-b263-373f5b10b145.pdf",
              "status": "found"
            },
            {
              "id": "jpm-presentation-2024Q1",
              "bankId": "jpm",
              "docType": "presentation",
              "period":"2025Q1",
              
              "name": "JPMorgan Chase",
              "url": "https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2023/4th-quarter/4423-earnings-presentation.pdf",
              "status": "found"
            },
            {
              "id": "bac-press-2024Q1",
              "bankId": "bac",
              "period":"2025Q1",
              "docType": "press",
              "name": "Bank of America",
              "url": "https://investor.bankofamerica.com/quarterly-earnings/content/dam/investor-relations/financial-information/quarterly-earnings/2023/q4/q4-2023-bac-earnings-press-release.pdf",
              "status": "found"
            },
            {
              "id": "bac-presentation-2024Q1",
              "bankId": "bac",
              "docType": "presentation",
              "name": "Bank of America",
              "url": "https://investor.bankofamerica.com/quarterly-earnings/content/dam/investor-relations/financial-information/quarterly-earnings/2023/q4/q4-2023-bac-earnings-presentation.pdf",
              "status": "not_found"
            }
          ]
          setResult({files:rowdata});
        } finally {
          setLoading(false);
        }
      };
    return (
        <Container maxWidth={false} disableGutters sx={{ px: 2 }}>
   
            <Grid container spacing={2}>
                <Grid item xs={12} sm={12}>
                    <FormControl size="small" fullWidth sx={{ m: 1, width: 430, mt: 3 }}>
                        <FormLabel style={{fontSize:'14px'}}>Bank(s)</FormLabel>
                        <Select
style={{fontSize:'14px'}}
                            multiple
                            value={selectedBanks}
                            onChange={(e) => setSelectedBanks(e.target.value)}
                            renderValue={(selected) => selected.join(', ')}
                        >
                            {banks.map((bank) => (
                                <MenuItem key={bank.id} value={bank.name}>
                                    <Checkbox checked={selectedBanks.includes(bank.name)} />
                                    <ListItemText primary={bank.name} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} sm={12}>
                    <FormControl size="small" fullWidth sx={{ m: 1, width: 430, mt: 3 }}>
                        <FormLabel style={{fontSize:'14px'}}>Document Type(s)</FormLabel>
                        <Select
                        style={{fontSize:'14px'}}
                            multiple
                            value={selectedDocs}
                            onChange={(e) => setSelectedDocs(e.target.value)}
                            renderValue={(selected) => selected.join(', ')}
                        >
                            {docTypes.map((type) => (
                                <MenuItem key={type} value={type}>
                                    <Checkbox checked={selectedDocs.includes(type)} />
                                    <ListItemText primary={type} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} sm={4}>
                    <FormControl size="small" fullWidth sx={{ m: 1, width: 430, mt: 3 }}>
                        <FormLabel style={{fontSize:'14px'}}>Quarter(s)</FormLabel>
                        <Select
                        style={{fontSize:'14px'}}
                            multiple
                            value={selectedQuarters}
                            onChange={(e) => setSelectedQuarters(e.target.value)}
                            renderValue={(selected) => selected.join(', ')}
                        >
                            {quarters.map((q) => (
                                <MenuItem key={q} value={q}>
                                    <Checkbox checked={selectedQuarters.includes(q)} />
                                    <ListItemText primary={q} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                <FormControl size="small" fullWidth sx={{ m: 1, width: 200, mt: 3 , paddingTop:3}}>
               
                    <Button
                        fullWidth
                        variant="contained"
                        onClick={handleSearch}
                        disabled={
                            !selectedBanks.length || !selectedDocs.length || !selectedQuarters.length || loading
                        }
                    >
                        {loading ? <CircularProgress size={24} /> : '🔍 Search'}
                    </Button>

</FormControl>
                   
                      
                   
                </Grid>
               
            </Grid>
          

            {result?.files?.length > 0 && (
  <DocResultsTable results={result.files} />
  
)}         

        </Container>
    );
}

export default DocSearchForm;
