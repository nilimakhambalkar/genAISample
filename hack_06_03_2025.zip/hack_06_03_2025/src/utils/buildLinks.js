export function buildBankLinks({ banks, quarters, selectedBanks, selectedDocs, selectedQuarters }) {
  const result = [];

  for (const bank of banks) {
    if (!selectedBanks.includes(bank.id)) continue;

    for (const quarterLabel of selectedQuarters) {
      const quarterObj = quarters.find((q) => q.label === quarterLabel);
      if (!quarterObj) continue;

      for (const docType of selectedDocs) {
        const { year, quarter } = quarterObj;

        const url = bank.pathTemplate
          .replace('{year}', year)
          .replace('{quarter}', quarter)
          .replace('{type}', docType);

        result.push({
          bank: bank.name,
          year,
          quarter,
          type: docType,
          url: bank.irUrl + url,
        });
      }
    }
  }

  return result;
}
