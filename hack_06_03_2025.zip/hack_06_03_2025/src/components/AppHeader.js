import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,

  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Box,
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses
} from '@mui/material';


import HomeIcon from '@mui/icons-material/Home';
import InfoIcon from '@mui/icons-material/Info';
import ArticleIcon from '@mui/icons-material/Article';
import DownloadIcon from '@mui/icons-material/Download';
import TableChartIcon from '@mui/icons-material/TableChart';
import ChatIcon from '@mui/icons-material/Chat';
import AssessmentIcon from '@mui/icons-material/Assessment';
import { styled } from '@mui/material/styles';

const drawerWidth = 240;

const steps = [
  'Data Collection',
  'Data Extraction',
  'Commentary Analysis',
  'Reporting & Presentation'
];

const activeStep = 0;

const ColorlibConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient(95deg,#4caf50 0%,#81c784 50%,#66bb6a 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient(95deg,#4caf50 0%,#81c784 50%,#66bb6a 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

const ColorlibStepIconRoot = styled('div')(({ theme, ownerState }) => ({

  backgroundColor: '#ccc',
  zIndex: 1,
  color: '#fff',
  width: 40,
  height: 40,
  display: 'flex',
  borderRadius: '50%',
  justifyContent: 'center',
  alignItems: 'center',
  ...(ownerState.active && {
    backgroundImage:
      'linear-gradient(136deg, #4caf50 0%, #81c784 50%, #66bb6a 100%)',
    boxShadow: '0 4px 10px 0 rgba(0,0,0,.25)',
  }),
  ...(ownerState.completed && {
    backgroundImage:
      'linear-gradient(136deg, #0cc414 0%, #45cf4b 50%, #ccf4ce 100%)',
      
  }),
}));
function ColorlibStepIcon(props) {
    const { active, completed, className } = props;
  
    const icons = {
      1: <DownloadIcon />,
      2: <TableChartIcon />,
      3: <ChatIcon />,
      4: <AssessmentIcon />,
    };
  
    return (
      <ColorlibStepIconRoot
        className={className}
        ownerState={{ active, completed }}
      >
        {icons[String(props.icon)]}
      </ColorlibStepIconRoot>
    );
  }

export default function AppHeader() {
  const [open, setOpen] = useState(false);

  const toggleDrawer = (state) => () => setOpen(state);

  const navItems = [
    { text: 'Home', icon: <HomeIcon /> },
    { text: 'Docs', icon: <ArticleIcon /> },
    { text: 'About', icon: <InfoIcon /> }
  ];

  return (
    <>
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
      <Toolbar sx={{ justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' }}>
  {/* Left section: Logo + Title */}
  <Box sx={{ display: 'flex', alignItems: 'center' }}>
  {/*   <IconButton edge="start" color="inherit" onClick={toggleDrawer(true)} sx={{ mr: 2 }}>
      <MenuIcon />
    </IconButton>*/}
    <Typography variant="h6" noWrap>
      📂 Peer Bank Analysis Tool
    </Typography>
  </Box>

  {/* Right or Centered Stepper (Choose layout mode below) */}
  <Box
    sx={{
        paddingTop:'10px',
      flexGrow: 1,
      display: 'flex',
      justifyContent: 'right', // 👉 center it horizontally
      // justifyContent: 'flex-end', // 👉 use this instead to align right
      mt: { xs: 2, sm: 0 },
    }}
  >
    <Stepper
      activeStep={activeStep}
      alternativeLabel
      connector={<ColorlibConnector />}
      sx={{ maxWidth: '100%', width:"50%" }}
    >
      {steps.map((label, index) => (
        <Step key={label} >
          <StepLabel StepIconComponent={ColorlibStepIcon}>
            <Typography
              variant="caption"
              sx={{
                color: index === activeStep ? 'green' : 'inherit',
                fontWeight: index === activeStep ? 'bold' : 'normal',
              }}
            >
            
            </Typography>
          </StepLabel>
        </Step>
      ))}
    </Stepper>
  </Box>
</Toolbar>

        
      </AppBar>

      <Drawer anchor="left" open={open} onClose={toggleDrawer(false)}>
        <Box
          sx={{ width: drawerWidth }}
          role="presentation"
          onClick={toggleDrawer(false)}
          onKeyDown={toggleDrawer(false)}
        >
          <Typography variant="h6" sx={{ p: 2 }}>
            Navigation
          </Typography>
          <Divider />
          <List>
            {navItems.map((item, index) => (
              <ListItem button key={index}>
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  );
}