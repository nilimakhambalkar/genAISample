import React, { useState } from 'react';
import {
  Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Paper, Typography, Button, CircularProgress
} from '@mui/material';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import ViewComfyAltIcon from '@mui/icons-material/ViewComfyAlt';

import { styled } from '@mui/material/styles';

import CloudUploadIcon from '@mui/icons-material/CloudUpload';

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});
function DocResultsTable({ results }) {
    const [loading, setLoading] = useState(false);
  if (!results?.length) {
    return <Typography>No results available.</Typography>;
  }

  return (
      <div>
     
    <TableContainer component={Paper} sx={{ mt: 3 }}>
      <Table>
        <TableHead style={{backgroundColor:'rgb(232 241 250)'}}>
          <TableRow>
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>Bank Name</strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>Document Type</strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>Period </strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}} ><strong>Status</strong></TableCell>
            <TableCell style={{padding:'10px' , textAlign:'center'}}><strong> Download</strong></TableCell>
            <TableCell style={{padding:'10px', textAlign:'center'}}><strong>🌐 View Source</strong></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {results.map((doc) => (
            <TableRow key={doc.id}>
              <TableCell style={{padding:'10px', textAlign:'center'}}> {doc.name}</TableCell>
              <TableCell style={{padding:'10px', textAlign:'center'}}> {doc.docType}</TableCell>
              <TableCell style={{padding:'10px', textAlign:'center'}}> {doc.period}</TableCell>

              <TableCell style={{padding:'10px', textAlign:'center'}}>
                <Button
                style={{fontSize:'10px', borderRadius:'20px'}}
                  size="small"
                  variant="contained"
                  color={doc.status === 'found' ? 'success' : 'error'}
                  
                >
                  {doc.status.toUpperCase()}
                </Button>
              </TableCell>

              <TableCell style={{padding:'10px', textAlign:'center'}}>
                {doc.status === 'found' ? (
                  <CloudDownloadIcon
                  style={{cursor:'pointer'}}
                    size="small"
                    variant="contained"
                    color="primary"
                    href={doc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e)=>{window.open(doc.url)}}
                  >
                   
                  </CloudDownloadIcon>
                ) : (
                  <CloudDownloadIcon size="small" variant="contained" disabled >
                   
                  </CloudDownloadIcon>
                )}
              </TableCell>

              <TableCell style={{padding:'10px', textAlign:'center'}}>
                {doc.status === 'found' ? (
                  <ViewComfyAltIcon
                  style={{cursor:'pointer'}}
                    size="small"
                    variant="contained"
                    color="primary"
                    href={doc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e)=>{window.open(doc.url)}}
                  >
                    View
                  </ViewComfyAltIcon>
                ) : (
                  <ViewComfyAltIcon size="small" variant="contained" >
                    N/A
                  </ViewComfyAltIcon>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <Button style={{marginTop:'20px'}}
      component="label"
      role={undefined}
      variant="contained"
      tabIndex={-1}
      startIcon={<CloudUploadIcon />}
    >
      {loading ? <CircularProgress size={24} /> : 'Download All'}
      
    </Button>
    

      </div>
  );
}

export default DocResultsTable;
